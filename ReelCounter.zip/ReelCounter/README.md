# Reel Counter (Android)

Counts Instagram Reels and YouTube Shorts using an Accessibility Service and shows a draggable floating counter.

## Build
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Connect your phone (USB debugging on) and press Run.
3. On the phone: open Reel Counter, tap "Open Accessibility Settings", enable "Reel Counter".
4. If the toggle is greyed out: App info > three-dot menu > "Allow restricted settings", then try again.

## If counting does not work
Instagram and YouTube rename internal view ids in updates. Edit REELS_IDS / SHORTS_IDS in ReelAccessibilityService.kt.
