package com.sourav.reelcounter

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CounterStore {
    const val KIND_REELS = "reels"
    const val KIND_SHORTS = "shorts"
    const val MODE_ASK = "ask"
    const val MODE_AUTO = "auto"

    private const val PREFS = "reel_counter"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun get(c: Context, kind: String): Int = prefs(c).getInt("${kind}_${today()}", 0)

    fun increment(c: Context, kind: String): Int {
        val n = get(c, kind) + 1
        prefs(c).edit().putInt("${kind}_${today()}", n).apply()
        return n
    }

    fun resetToday(c: Context) {
        prefs(c).edit()
            .remove("${KIND_REELS}_${today()}")
            .remove("${KIND_SHORTS}_${today()}")
            .apply()
    }

    fun getMode(c: Context): String = prefs(c).getString("mode", MODE_ASK) ?: MODE_ASK

    fun setMode(c: Context, mode: String) {
        prefs(c).edit().putString("mode", mode).apply()
    }

    fun getPosX(c: Context, default: Int): Int = prefs(c).getInt("pos_x", default)
    fun getPosY(c: Context, default: Int): Int = prefs(c).getInt("pos_y", default)

    fun setPos(c: Context, x: Int, y: Int) {
        prefs(c).edit().putInt("pos_x", x).putInt("pos_y", y).apply()
    }

    fun getDebug(c: Context): String = prefs(c).getString("debug", "") ?: ""

    fun setDebug(c: Context, text: String) {
        prefs(c).edit().putString("debug", text).apply()
    }
}
