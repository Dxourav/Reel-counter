package com.sourav.reelcounter

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val bg = Color.parseColor("#1E0F36")
    private val cardColor = Color.parseColor("#3B215D")
    private val gold = Color.parseColor("#D4AF37")
    private val soft = Color.parseColor("#CFC3E3")
    private val okColor = Color.parseColor("#4CAF50")
    private val badColor = Color.parseColor("#EF5350")

    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var reelsNum: TextView
    private lateinit var shortsNum: TextView
    private lateinit var totalNum: TextView
    private lateinit var debugView: TextView
    private lateinit var askRadio: RadioButton
    private lateinit var autoRadio: RadioButton

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        background = rounded(cardColor, 20)
    }

    private fun params(top: Int = 14) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun goldButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(bg)
        background = rounded(gold, 14)
        stateListAnimator = null
        setPadding(dp(16), dp(12), dp(16), dp(12))
        setOnClickListener { onClick() }
    }

    private fun outlineButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(gold)
        background = rounded(Color.TRANSPARENT, 14, gold)
        stateListAnimator = null
        setPadding(dp(16), dp(10), dp(16), dp(10))
        setOnClickListener { onClick() }
    }

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(gold)
        letterSpacing = 0.1f
    }

    private fun statCard(label: String): Pair<LinearLayout, TextView> {
        val c = card()
        val num = TextView(this).apply {
            textSize = 38f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
        }
        val lab = TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(soft)
        }
        c.addView(num)
        c.addView(lab)
        return Pair(c, num)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(28))
        }

        root.addView(TextView(this).apply {
            text = "Reel Counter"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
        })
        root.addView(TextView(this).apply {
            text = "Know your scroll. Own your time."
            textSize = 14f
            setTextColor(soft)
        })

        // Status card
        val statusCard = card()
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        statusDot = View(this)
        statusDot.layoutParams = LinearLayout.LayoutParams(dp(12), dp(12)).apply {
            marginEnd = dp(10)
        }
        statusText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
        }
        statusRow.addView(statusDot)
        statusRow.addView(statusText)
        statusCard.addView(statusRow)
        statusCard.addView(
            goldButton("Open Accessibility Settings") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            params(14)
        )
        root.addView(statusCard, params(22))

        // Today
        root.addView(sectionTitle("TODAY"), params(26))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val (reelsCard, rn) = statCard("Instagram Reels")
        val (shortsCard, sn) = statCard("YouTube Shorts")
        reelsNum = rn
        shortsNum = sn
        row.addView(reelsCard, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = dp(6)
        })
        row.addView(shortsCard, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(6)
        })
        root.addView(row, params(10))
        val (totalCard, tn) = statCard("Total today")
        totalNum = tn
        root.addView(totalCard, params(12))
        root.addView(outlineButton("Reset today's counts") {
            CounterStore.resetToday(this)
            refresh()
        }, params(12))

        // Mode
        root.addView(sectionTitle("WHEN INSTAGRAM OR YOUTUBE OPENS"), params(26))
        val modeCard = card()
        askRadio = RadioButton(this).apply {
            text = "Ask me with a pop-up"
            id = 1001
            setTextColor(Color.WHITE)
            buttonTintList = ColorStateList.valueOf(gold)
        }
        autoRadio = RadioButton(this).apply {
            text = "Start counting automatically"
            id = 1002
            setTextColor(Color.WHITE)
            buttonTintList = ColorStateList.valueOf(gold)
        }
        val group = RadioGroup(this).apply {
            addView(askRadio)
            addView(autoRadio)
            setOnCheckedChangeListener { _, checked ->
                CounterStore.setMode(
                    this@MainActivity,
                    if (checked == 1002) CounterStore.MODE_AUTO else CounterStore.MODE_ASK
                )
            }
        }
        modeCard.addView(group)
        root.addView(modeCard, params(10))

        // Diagnostics
        root.addView(sectionTitle("DIAGNOSTICS (FOR TROUBLESHOOTING)"), params(26))
        val diagCard = card()
        debugView = TextView(this).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(soft)
            setTextIsSelectable(true)
        }
        diagCard.addView(debugView)
        root.addView(diagCard, params(10))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val on = isServiceEnabled()
        statusDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) okColor else badColor)
        }
        statusText.text = if (on) {
            "Service is ON"
        } else {
            "Service is OFF. Tap below, open \"Reel Counter\" and switch it on."
        }

        if (CounterStore.getMode(this) == CounterStore.MODE_AUTO) {
            autoRadio.isChecked = true
        } else {
            askRadio.isChecked = true
        }

        val reels = CounterStore.get(this, CounterStore.KIND_REELS)
        val shorts = CounterStore.get(this, CounterStore.KIND_SHORTS)
        reelsNum.text = reels.toString()
        shortsNum.text = shorts.toString()
        totalNum.text = (reels + shorts).toString()

        val dbg = CounterStore.getDebug(this)
        debugView.text = if (dbg.isEmpty()) {
            "No data yet. Open Instagram, scroll Reels, open the comments and scroll them, then come back here."
        } else dbg
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = "$packageName/${ReelAccessibilityService::class.java.name}"
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }
}
