package com.sourav.reelcounter

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var countsView: TextView
    private lateinit var askRadio: RadioButton
    private lateinit var autoRadio: RadioButton

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Reel Counter"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
        })

        statusView = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(16), 0, dp(8))
        }
        root.addView(statusView)

        root.addView(Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        root.addView(TextView(this).apply {
            text = "When Instagram or YouTube opens:"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(24), 0, dp(4))
        })

        askRadio = RadioButton(this).apply { text = "Ask me with a pop-up"; id = 1001 }
        autoRadio = RadioButton(this).apply { text = "Start counting automatically"; id = 1002 }
        val group = RadioGroup(this).apply {
            addView(askRadio)
            addView(autoRadio)
            setOnCheckedChangeListener { _, checked ->
                CounterStore.setMode(
                    this@MainActivity,
                    if (checked == 1002) CounterStore.MODE_AUTO else CounterStore.MODE_ASK
                )
            }
        }
        root.addView(group)

        root.addView(TextView(this).apply {
            text = "Today"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(24), 0, dp(4))
        })

        countsView = TextView(this).apply { textSize = 18f }
        root.addView(countsView)

        root.addView(Button(this).apply {
            text = "Reset today's counts"
            setOnClickListener {
                CounterStore.resetToday(this@MainActivity)
                refresh()
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        statusView.text = if (isServiceEnabled()) {
            "Service status: ON"
        } else {
            "Service status: OFF. Tap the button below, open \"Reel Counter\" and switch it on."
        }

        if (CounterStore.getMode(this) == CounterStore.MODE_AUTO) {
            autoRadio.isChecked = true
        } else {
            askRadio.isChecked = true
        }

        val reels = CounterStore.get(this, CounterStore.KIND_REELS)
        val shorts = CounterStore.get(this, CounterStore.KIND_SHORTS)
        countsView.text = "Instagram Reels: $reels\nYouTube Shorts: $shorts\nTotal: ${reels + shorts}"
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = "$packageName/${ReelAccessibilityService::class.java.name}"
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }
}
