package com.sourav.reelcounter

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class ReelAccessibilityService : AccessibilityService() {

    companion object {
        private const val INSTAGRAM = "com.instagram.android"
        private const val YOUTUBE = "com.google.android.youtube"

        // One swipe fires a burst of scroll events; count only one per this window.
        private const val DEBOUNCE_MS = 700L
        private const val PROMPT_TIMEOUT_MS = 10_000L

        // View-id fragments that identify the full-screen Reels / Shorts player.
        // If an app update changes these, only this list needs editing.
        private val REELS_IDS = listOf("clips_viewer")
        private val SHORTS_IDS = listOf("reel_player", "reel_recycler", "reel_watch")
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private var bubbleText: TextView? = null
    private var prompt: View? = null

    private var currentKind: String? = null
    private var tracking = false
    private var sessionCount = 0
    private var lastCountAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        removePrompt()
        removeBubble()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString() ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> onWindowChanged(pkg)
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> onScrolled(e, pkg)
        }
    }

    // ---------- App open / close detection ----------

    private fun kindFor(pkg: String): String? = when (pkg) {
        INSTAGRAM -> CounterStore.KIND_REELS
        YOUTUBE -> CounterStore.KIND_SHORTS
        else -> null
    }

    private fun labelFor(kind: String) =
        if (kind == CounterStore.KIND_REELS) "Reels" else "Shorts"

    private fun isIgnorable(pkg: String) =
        pkg == packageName ||
            pkg == "com.android.systemui" ||
            pkg.contains("inputmethod") ||
            pkg.contains("keyboard")

    private fun onWindowChanged(pkg: String) {
        val kind = kindFor(pkg)
        if (kind != null) {
            if (currentKind != kind) {
                currentKind = kind
                tracking = false
                sessionCount = 0
                removePrompt()
                removeBubble()
                if (CounterStore.getMode(this) == CounterStore.MODE_AUTO) {
                    startTracking()
                } else {
                    showPrompt(kind)
                }
            }
        } else if (!isIgnorable(pkg) && currentKind != null) {
            currentKind = null
            tracking = false
            removePrompt()
            removeBubble()
        }
    }

    private fun startTracking() {
        if (currentKind == null) return
        tracking = true
        sessionCount = 0
        showBubble()
    }

    private fun stopTracking() {
        tracking = false
        removeBubble()
    }

    // ---------- Counting ----------

    private fun onScrolled(e: AccessibilityEvent, pkg: String) {
        if (!tracking) return
        val kind = kindFor(pkg) ?: return
        if (kind != currentKind) return

        // Ignore purely horizontal scrolls (carousels, tabs).
        if (Build.VERSION.SDK_INT >= 28 && e.scrollDeltaX != 0 && e.scrollDeltaY == 0) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastCountAt < DEBOUNCE_MS) return

        val root = rootInActiveWindow ?: return
        val keys = if (kind == CounterStore.KIND_REELS) REELS_IDS else SHORTS_IDS
        if (!containsId(root, keys, 0)) return

        lastCountAt = now
        sessionCount++
        CounterStore.increment(this, kind)
        updateBubble()
    }

    private fun containsId(node: AccessibilityNodeInfo?, keys: List<String>, depth: Int): Boolean {
        if (node == null || depth > 30) return false
        val id = node.viewIdResourceName
        if (id != null && keys.any { id.contains(it) }) return true
        for (i in 0 until node.childCount) {
            if (containsId(node.getChild(i), keys, depth + 1)) return true
        }
        return false
    }

    // ---------- Overlay UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun overlayParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )

    private fun showPrompt(kind: String) {
        removePrompt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
            background = rounded(Color.parseColor("#F2202124"), 20)
        }
        box.addView(TextView(this).apply {
            text = "Count your ${labelFor(kind)} in this session?"
            setTextColor(Color.WHITE)
            textSize = 15f
        })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(10), 0, 0)
        }
        row.addView(Button(this).apply {
            text = "No"
            setOnClickListener { removePrompt() }
        })
        row.addView(Button(this).apply {
            text = "Turn on"
            setOnClickListener {
                removePrompt()
                startTracking()
            }
        })
        box.addView(row)

        val lp = overlayParams().apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(80)
        }
        wm.addView(box, lp)
        prompt = box
        handler.postDelayed({ if (prompt === box) removePrompt() }, PROMPT_TIMEOUT_MS)
    }

    private fun removePrompt() {
        prompt?.let { runCatching { wm.removeView(it) } }
        prompt = null
    }

    private fun showBubble() {
        removeBubble()
        val text = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
        }
        val close = TextView(this).apply {
            this.text = "\u2715"
            setTextColor(Color.LTGRAY)
            textSize = 16f
            setPadding(dp(14), dp(4), 0, dp(4))
            setOnClickListener { stopTracking() }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(Color.parseColor("#E6311B92"), 18)
            addView(text)
            addView(close)
        }

        val lp = overlayParams().apply {
            gravity = Gravity.TOP or Gravity.START
            x = CounterStore.getPosX(this@ReelAccessibilityService, dp(16))
            y = CounterStore.getPosY(this@ReelAccessibilityService, dp(200))
        }

        box.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var downX = 0f
            var downY = 0f
            override fun onTouch(v: View, ev: MotionEvent): Boolean {
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y
                        downX = ev.rawX; downY = ev.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = startX + (ev.rawX - downX).toInt()
                        lp.y = startY + (ev.rawY - downY).toInt()
                        runCatching { wm.updateViewLayout(v, lp) }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        CounterStore.setPos(this@ReelAccessibilityService, lp.x, lp.y)
                        return true
                    }
                }
                return false
            }
        })

        wm.addView(box, lp)
        bubble = box
        bubbleText = text
        updateBubble()
    }

    private fun updateBubble() {
        val kind = currentKind ?: return
        bubbleText?.text =
            "${labelFor(kind)}: $sessionCount\nToday: ${CounterStore.get(this, kind)}"
    }

    private fun removeBubble() {
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        bubbleText = null
    }
}
