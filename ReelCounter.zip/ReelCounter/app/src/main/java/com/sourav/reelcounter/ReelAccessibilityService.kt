package com.sourav.reelcounter

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class ReelAccessibilityService : AccessibilityService() {

    companion object {
        private const val INSTAGRAM = "com.instagram.android"
        private const val YOUTUBE = "com.google.android.youtube"

        // One swipe fires a burst of scroll events; count only one per this window.
        private const val DEBOUNCE_MS = 700L
        private const val PROMPT_TIMEOUT_MS = 10_000L
        private const val LOG_THROTTLE_MS = 400L
        private const val MAX_LOG = 6

        // View-id fragments that identify the full-screen Reels / Shorts player.
        private val REELS_IDS = listOf("clips_viewer")
        private val SHORTS_IDS = listOf("reel_player", "reel_recycler", "reel_watch")

        // View-id fragments that identify the comments panel.
        private val COMMENT_IDS = listOf(
            "layout_comment_thread", "comment_composer", "row_comment_",
            "comment_thread", "comments_sheet", "engagement_panel"
        )

        // KKR theme
        private val BG = Color.parseColor("#1E0F36")
        private val PURPLE = Color.parseColor("#F23B215D")
        private val GOLD = Color.parseColor("#D4AF37")
        private val SOFT = Color.parseColor("#CFC3E3")
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private var bubbleMain: TextView? = null
    private var bubbleSub: TextView? = null
    private var prompt: View? = null

    private var currentKind: String? = null
    private var tracking = false
    private var sessionCount = 0
    private var lastCountAt = 0L
    private var lastLogAt = 0L
    private val debugLines = ArrayDeque<String>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        removePrompt()
        removeBubble()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString() ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> onWindowChanged(pkg)
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> onScrolled(e, pkg)
        }
    }

    // ---------- App open / close detection ----------

    private fun kindFor(pkg: String): String? = when (pkg) {
        INSTAGRAM -> CounterStore.KIND_REELS
        YOUTUBE -> CounterStore.KIND_SHORTS
        else -> null
    }

    private fun labelFor(kind: String) =
        if (kind == CounterStore.KIND_REELS) "Reels" else "Shorts"

    private fun isIgnorable(pkg: String) =
        pkg == packageName ||
            pkg == "com.android.systemui" ||
            pkg.contains("inputmethod") ||
            pkg.contains("keyboard")

    private fun onWindowChanged(pkg: String) {
        val kind = kindFor(pkg)
        if (kind != null) {
            if (currentKind != kind) {
                currentKind = kind
                tracking = false
                sessionCount = 0
                removePrompt()
                removeBubble()
                if (CounterStore.getMode(this) == CounterStore.MODE_AUTO) {
                    startTracking()
                } else {
                    showPrompt(kind)
                }
            }
        } else if (!isIgnorable(pkg) && currentKind != null) {
            currentKind = null
            tracking = false
            removePrompt()
            removeBubble()
        }
    }

    private fun startTracking() {
        if (currentKind == null) return
        tracking = true
        sessionCount = 0
        showBubble()
    }

    private fun stopTracking() {
        tracking = false
        removeBubble()
    }

    // ---------- Counting ----------

    private fun onScrolled(e: AccessibilityEvent, pkg: String) {
        if (!tracking) return
        val kind = kindFor(pkg) ?: return
        if (kind != currentKind) return

        // Ignore purely horizontal scrolls (carousels, tabs).
        if (Build.VERSION.SDK_INT >= 28 && e.scrollDeltaX != 0 && e.scrollDeltaY == 0) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastCountAt < DEBOUNCE_MS) return

        val keys = if (kind == CounterStore.KIND_REELS) REELS_IDS else SHORTS_IDS
        val verdict = judge(e, keys)
        if (verdict != null) {
            log(now, kind, "SKIP $verdict", e)
            return
        }

        lastCountAt = now
        sessionCount++
        CounterStore.increment(this, kind)
        updateBubble()
        log(now, kind, "COUNT", e)
    }

    // Returns null when the swipe should be counted, otherwise the reason it was skipped.
    private fun judge(e: AccessibilityEvent, keys: List<String>): String? {
        val src = e.source ?: return "no-source"

        var inPlayer = false
        var node: AccessibilityNodeInfo? = src
        var hops = 0
        while (node != null && hops < 25) {
            val id = node.viewIdResourceName
            if (id != null) {
                if (COMMENT_IDS.any { id.contains(it) }) return "in-comments"
                if (keys.any { id.contains(it) }) inPlayer = true
            }
            node = node.parent
            hops++
        }

        val root = rootInActiveWindow ?: return "no-root"
        if (commentsOpen(root, 0)) return "comments-open"
        if (inPlayer) return null
        return if (hasBigVisibleNode(root, keys, 0)) null else "not-player"
    }

    private fun commentsOpen(node: AccessibilityNodeInfo?, depth: Int): Boolean {
        if (node == null || depth > 30) return false
        if (node.isVisibleToUser) {
            val id = node.viewIdResourceName
            if (id != null && COMMENT_IDS.any { id.contains(it) }) return true
            if (node.className?.toString() == "android.widget.EditText") return true
            val t = node.text?.toString()
            if (t != null && t.equals("Comments", ignoreCase = true)) return true
            val d = node.contentDescription?.toString()
            if (d != null && d.equals("Comments", ignoreCase = true)) return true
        }
        for (i in 0 until node.childCount) {
            if (commentsOpen(node.getChild(i), depth + 1)) return true
        }
        return false
    }

    private fun hasBigVisibleNode(node: AccessibilityNodeInfo?, keys: List<String>, depth: Int): Boolean {
        if (node == null || depth > 30) return false
        val id = node.viewIdResourceName
        if (id != null && keys.any { id.contains(it) } && node.isVisibleToUser) {
            val r = Rect()
            node.getBoundsInScreen(r)
            val dm = resources.displayMetrics
            if (r.height() >= dm.heightPixels * 0.6 && r.width() >= dm.widthPixels * 0.6) return true
        }
        for (i in 0 until node.childCount) {
            if (hasBigVisibleNode(node.getChild(i), keys, depth + 1)) return true
        }
        return false
    }

    // Keeps the last few decisions so problems can be diagnosed from the app screen.
    private fun log(now: Long, kind: String, result: String, e: AccessibilityEvent) {
        if (result.startsWith("SKIP") && now - lastLogAt < LOG_THROTTLE_MS) return
        lastLogAt = now
        val chain = StringBuilder()
        var node: AccessibilityNodeInfo? = e.source
        var hops = 0
        while (node != null && hops < 6) {
            val id = node.viewIdResourceName?.substringAfter(":id/") ?: "-"
            val cls = node.className?.toString()?.substringAfterLast('.') ?: "?"
            chain.append(id).append('(').append(cls).append(")<")
            node = node.parent
            hops++
        }
        debugLines.addFirst("${labelFor(kind)} $result | $chain")
        while (debugLines.size > MAX_LOG) debugLines.removeLast()
        CounterStore.setDebug(this, debugLines.joinToString("\n\n"))
    }

    // ---------- Overlay UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int? = null, strokeDp: Int = 1) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(strokeDp), strokeColor)
        }

    private fun overlayParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )

    private fun styledButton(label: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        minHeight = 0
        minimumHeight = 0
        stateListAnimator = null
        setPadding(dp(18), dp(8), dp(18), dp(8))
        if (filled) {
            setTextColor(BG)
            background = rounded(GOLD, 12)
        } else {
            setTextColor(SOFT)
            background = rounded(Color.TRANSPARENT, 12)
        }
        setOnClickListener { onClick() }
    }

    private fun showPrompt(kind: String) {
        removePrompt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(12))
            background = rounded(PURPLE, 22, GOLD, 2)
        }
        box.addView(TextView(this).apply {
            text = "Count your ${labelFor(kind)} in this session?"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
        })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(12), 0, 0)
        }
        row.addView(styledButton("No", false) { removePrompt() })
        row.addView(
            styledButton("Turn on", true) {
                removePrompt()
                startTracking()
            },
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(8) }
        )
        box.addView(row)

        val lp = overlayParams().apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(80)
        }
        wm.addView(box, lp)
        prompt = box
        handler.postDelayed({ if (prompt === box) removePrompt() }, PROMPT_TIMEOUT_MS)
    }

    private fun removePrompt() {
        prompt?.let { runCatching { wm.removeView(it) } }
        prompt = null
    }

    private fun showBubble() {
        removeBubble()
        val main = TextView(this).apply {
            setTextColor(GOLD)
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            setTextColor(SOFT)
            textSize = 11f
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(main)
            addView(sub)
        }
        val close = TextView(this).apply {
            text = "\u2715"
            setTextColor(SOFT)
            textSize = 16f
            setPadding(dp(14), dp(4), 0, dp(4))
            setOnClickListener { stopTracking() }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = rounded(PURPLE, 18, GOLD, 2)
            addView(column)
            addView(close)
        }

        val lp = overlayParams().apply {
            gravity = Gravity.TOP or Gravity.START
            x = CounterStore.getPosX(this@ReelAccessibilityService, dp(16))
            y = CounterStore.getPosY(this@ReelAccessibilityService, dp(200))
        }

        box.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var downX = 0f
            var downY = 0f
            override fun onTouch(v: View, ev: MotionEvent): Boolean {
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = lp.x; startY = lp.y
                        downX = ev.rawX; downY = ev.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = startX + (ev.rawX - downX).toInt()
                        lp.y = startY + (ev.rawY - downY).toInt()
                        runCatching { wm.updateViewLayout(v, lp) }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        CounterStore.setPos(this@ReelAccessibilityService, lp.x, lp.y)
                        return true
                    }
                }
                return false
            }
        })

        wm.addView(box, lp)
        bubble = box
        bubbleMain = main
        bubbleSub = sub
        updateBubble()
    }

    private fun updateBubble() {
        val kind = currentKind ?: return
        bubbleMain?.text = "${labelFor(kind)}  $sessionCount"
        bubbleSub?.text = "Today ${CounterStore.get(this, kind)}"
    }

    private fun removeBubble() {
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        bubbleMain = null
        bubbleSub = null
    }
}
